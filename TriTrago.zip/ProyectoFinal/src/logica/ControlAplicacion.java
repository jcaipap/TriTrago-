
package logica;

import Datos.CatalogoDataBaseHandler;
import Datos.Licor;
import Datos.Producto;
import Datos.Usuario;
import Datos.UsuariosDataBaseHandler;
import java.util.ArrayList;
import java.util.TreeMap;
import ui.GUIBuscador;
import ui.GUICarrito;
import ui.GUIInicio;
import ui.GUIPago;


public class ControlAplicacion {


    public static void main(String[] args) {
        

        
        UsuariosDataBaseHandler controladorBaseUsuariosGeneracion= new UsuariosDataBaseHandler();
        CatalogoDataBaseHandler controladorBaseCatalogo= new CatalogoDataBaseHandler();
        TreeMap<String,Usuario> baseDatosUsuarios = controladorBaseUsuariosGeneracion.LeerDBU();
        ArrayList<Licor> baseDatosCatalogo = controladorBaseCatalogo.LeerDBC();
        ArrayList<Producto> catalogo=new ArrayList<>();
        ArrayList<Producto> carrito=new ArrayList<>();
        
        
        catalogo.addAll(baseDatosCatalogo);

        GUIInicio inicio = new GUIInicio(baseDatosUsuarios, catalogo, controladorBaseUsuariosGeneracion, controladorBaseCatalogo,carrito);
        inicio.setLocationRelativeTo(null);
        inicio.setVisible(true);
        
        //GUIPago pago=new GUIPago(baseDatosUsuarios, catalogo, controladorBaseUsuariosGeneracion, controladorBaseCatalogo,carrito);
        //pago.setLocationRelativeTo(null);
        //pago.setVisible(true);

        
        
        
    }
    
   
}
