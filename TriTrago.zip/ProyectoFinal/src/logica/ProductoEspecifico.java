
package logica;

import Datos.Licor;
import Datos.Producto;
import java.util.ArrayList;


public class ProductoEspecifico {
    public static void modificarEspecifico(ArrayList<Producto> catalogo, Producto productoAñadir, int cantidad){
        productoAñadir.setCantidadProductos(productoAñadir.getCantidadProductos()-cantidad);
        catalogo.set(catalogo.indexOf(productoAñadir), productoAñadir);
    }
}
