
package logica;

import Datos.Usuario;
import java.util.TreeMap;

public class Inicio {
    
    

    public static boolean verificarUsuario(String usuario, String contraseña, TreeMap<String,Usuario> baseDatosUsuario){
        
        
        for(Usuario usuariosBaseDatos: baseDatosUsuario.values()){
            if((usuario == null ? usuariosBaseDatos.getUsuario() == null : usuario.equals(usuariosBaseDatos.getUsuario()))&&(contraseña == null ? usuariosBaseDatos.getContraseña() == null : contraseña.equals(usuariosBaseDatos.getContraseña()))){
                return true;
            }
        }
        
        return false;
    }
    

    
}
