
package logica;

import Datos.CatalogoDataBaseHandler;
import Datos.Licor;
import Datos.Producto;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;


public class Pago {
   

    public static boolean pagoTarjeta(String tarjeta, int fechaExpMes, int fechaExpYear, String cvv){             
        if ((fechaExpYear>2019 &&tarjeta.length()<18&&tarjeta.length()>16&&cvv.length()>=3&&fechaExpMes<13&&cvv.length()<=4)){
            return false;
        } else if (fechaExpYear==2019&&fechaExpMes>7){
            return false;
        } else{
            return true;
        }
        
    }
    public static int verificarCondicionError(String tarjeta,int fechaExpMes, int fechaExpYear, String cvv){
        if (fechaExpYear<2019||(fechaExpYear==2019&&fechaExpMes<7)){
            return 1;
        } else if (tarjeta.length()>18||tarjeta.length()<16){
            return 2;
        } else if (cvv.length()<3 || cvv.length()>4){
            return 3;
        } else if (fechaExpMes<13){
            return 4;
        } else {
            return 0;
        }
    }
    public static void actualizarBase(ArrayList<Producto> carrito) {
        CatalogoDataBaseHandler actualizar = new CatalogoDataBaseHandler();
        for (int i=0; i<carrito.size(); i++) {
            Producto producto= carrito.get(i);
            actualizar.ModificarDBC(producto.getCodigo(),producto.getCantidadProductos());
            producto.setCantidadProductos(producto.getCantidadProductos()-1);
            
        }
    }     
}
