
package logica;

import Datos.Usuario;
import Datos.UsuariosDataBaseHandler;
import java.util.TreeMap;
import logica.ControlErrores;

public class GeneracionUsuario {
    
    public static boolean validarDatosIngresados(String nombre,String apellido,String correo,String usuario,String contraseña,String reingresoContraseña, String edad,String id,TreeMap<String,Usuario> baseDatos){
        

        if(nombre==null||apellido==null||correo==null||usuario==null||contraseña==null||reingresoContraseña==null||edad==null){
            return false;
        }
        if(!contraseña.equals(reingresoContraseña)){
            return false;
        }
        if(!ControlErrores.comprobacionNumerica(edad)){
            return false;
        }

        if(!ControlErrores.comprobacionNumerica(id)){
            return false;
        }
        
        if (!baseDatos.values().stream().noneMatch((usuariosBaseDatos) -> (usuario.equals(usuariosBaseDatos.getUsuario())))) {
            return false;
        }
        
        for(Usuario generador: baseDatos.values()){
            if(generador.getId()==Integer.parseInt(id)){
                return false;
            }
        }
        

        return true;
    }

    
  public static void crearUsuario (TreeMap<String,Usuario> baseDatos,int id, String nombre, String apellido, int edad, String correo, String usuario, String contraseña, UsuariosDataBaseHandler controladorBaseUsuariosGeneracion){        
        controladorBaseUsuariosGeneracion.InsertarDBU(id, nombre, apellido, edad, correo, usuario, contraseña);
        baseDatos.put(contraseña, new Usuario(id, nombre, apellido, edad, correo, usuario, contraseña));
   
        
    }    
}
