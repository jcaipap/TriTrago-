
package logica;

import Datos.CatalogoDataBaseHandler;
import Datos.Licor;
import Datos.Producto;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class Buscador {
    
    
    public static ArrayList<Producto> preciosBajos(ArrayList<Producto> productos){
        ArrayList<Producto> ordenProductos =productos;
        Collections.sort(ordenProductos, (Producto p1, Producto p2) -> new Integer(p1.getPrecio()).compareTo(new Integer(p2.getPrecio())) 
        );
        return ordenProductos;
    }
    public static ArrayList<Producto> preciosAltos(ArrayList<Producto> productos){
        ArrayList<Producto> ordenProductos=productos;
        Collections.sort(ordenProductos, (Producto p2, Producto p1) -> new Integer(p1.getPrecio()).compareTo(new Integer(p2.getPrecio())) 
        );
        return ordenProductos;
    }
    public static ArrayList<Producto> rangoPrecios(int min, int max, ArrayList<Producto> productos){
       
        ArrayList<Producto> ordenProductos =new ArrayList<>();
        for (int i=0 ;i <productos.size();i++){   
            if (!((max<productos.get(i).getPrecio())||(productos.get(i).getPrecio()<min))){
                ordenProductos.add(productos.get(i));
                
            }
            ordenProductos=preciosBajos(ordenProductos);
        }
        
        return ordenProductos;
    } 
    public static ArrayList<Producto> filtroTipo (String tipo,ArrayList<Producto> catalogo){
       
        ArrayList<Producto> catalogoTipo = new ArrayList<>();
        tipo=tipo.toUpperCase();
        for (int i=0; i<catalogo.size();i++){
            if((tipo.equals(catalogo.get(i).getTipo().toUpperCase()))){
                catalogoTipo.add(catalogo.get(i));              
            }  
        } 
    return catalogoTipo;
    }
    public static ArrayList<Producto> filtroMarca (String marca,ArrayList<Producto> catalogo){
       
        ArrayList<Producto> catalogoMarca = new ArrayList<>();
        marca=marca.toUpperCase();
        
        for (int i=0; i<catalogo.size();i++){
            if((marca==catalogo.get(i).getMarca().toUpperCase())){
                catalogoMarca.add(catalogo.get(i));
                
            }
            
        } 
    return catalogoMarca;
    }
    public static ArrayList<Producto> filtroLugar (String lugar,ArrayList<Producto> catalogo){
       
        ArrayList<Producto> catalogoLugar = new ArrayList<>();
        lugar=lugar.toUpperCase();
        for (int i=0; i<catalogo.size();i++){
            String lugarProducto=catalogo.get(i).getPuntoVenta().toUpperCase();
            if((lugar.equals(lugarProducto))){
                catalogoLugar.add(catalogo.get(i));              
            }          
        } 
    return catalogoLugar;
    }

    //logica para crear ArrayLists a partir de criterios especificos, precio de menor a mayor, categoria, tipo, lugar, etc...
    
    
    
    
}
