
package logica;

import Datos.Producto;
import java.util.ArrayList;
import java.util.Iterator;


public class CarritoCompras {
    static ArrayList<Producto> carritoProductos = new ArrayList<>();
    public static ArrayList<Producto> separarLugar (String lugar, ArrayList<Producto> carritoProductos){
        ArrayList<Producto> productosLugar = new ArrayList<>();
        for (int i=0; i<carritoProductos.size();i++){
            if((lugar.equals(carritoProductos.get(i).getPuntoVenta()))){
                productosLugar.add(carritoProductos.get(i));              
            }          
        } 
    return productosLugar;
        }
    public static void vaciarCarrito (ArrayList<Producto> carritoProductos){
            carritoProductos.clear();
        }
    public static ArrayList<Producto> eliminarProducto(ArrayList<Producto> carritoProductos,String nombre, int cantidad){
        Iterator <Producto> itr=carritoProductos.iterator();
        while (itr.hasNext()){
            Producto pr=(Producto) itr.next();
            if (pr.getNombre().equals(nombre)){       
                //for(int i=0; i<cantidad;i++){
                    itr.remove();
                //}
            }
            
        }
        return carritoProductos;
    }
    public static void añadirProducto(ArrayList<Producto> carritoProductos, Producto productoAñadir, int cantidad){
        for (int i=0;i<cantidad;i++){
            carritoProductos.add(productoAñadir);
        }
    }
        //logica para separar los componentes de los productos por su punto de venta
        
    
}
