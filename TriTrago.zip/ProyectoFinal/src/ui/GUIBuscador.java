/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import Datos.CatalogoDataBaseHandler;
import Datos.Licor;
import Datos.Producto;
import Datos.Usuario;
import Datos.UsuariosDataBaseHandler;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.TreeMap;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import logica.Buscador;
import logica.wrapLayout;

/**
 *
 * @author JAndres
 */
public class GUIBuscador extends javax.swing.JFrame {
 
    /**
     * Creates new form GUIBuscador
     */
    ArrayList<Producto> catalogo;
    ArrayList<Producto> carrito;
    String valorBusqueda;
    UsuariosDataBaseHandler controladorBaseUsuariosGeneracion;
    CatalogoDataBaseHandler controladorBaseCatalogo;
    TreeMap <String, Usuario> baseDatosUsuarios;

    public GUIBuscador(ArrayList<Producto> catalogo, ArrayList<Producto> carrito,UsuariosDataBaseHandler controladorBaseUsuariosGeneracion, CatalogoDataBaseHandler controladorBaseCatalogo, TreeMap <String, Usuario> baseDatosUsuarios) {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        getContentPane().setBackground(Color.WHITE);
        this.catalogo = catalogo;
        this.carrito = carrito;
        this.baseDatosUsuarios=baseDatosUsuarios;
        this.controladorBaseCatalogo=controladorBaseCatalogo;
        this.controladorBaseUsuariosGeneracion=controladorBaseUsuariosGeneracion;
        crearCatalogo(catalogo);
        this.txtMin.setEnabled(false);
        this.txtMax.setEnabled(false);
        this.btnOrganizarPrecio.setEnabled(false);
        setIconImage(new ImageIcon(getClass().getResource("/recursos/iconoPrincipal.png")).getImage());
        this.setTitle("Buscador de productos");
        jLabel10.setText("Mostrando "+catalogo.size()+" resultados.");
        ImageIcon icon= new ImageIcon();
        Icon iconScale;
        Image image= new ImageIcon(getClass().getResource("/recursos/logoPrincipal.png")).getImage();
        icon.setImage(image);
        iconScale = new ImageIcon(icon.getImage().getScaledInstance(labelLogo.getWidth(), labelLogo.getHeight(), Image.SCALE_SMOOTH));
        labelLogo.setIcon(iconScale);


    }

    private void organizarPrecio(boolean verdad) {

        if (verdad) {
            this.txtMin.setEnabled(true);
            this.txtMax.setEnabled(true);
            this.btnOrganizarPrecio.setEnabled(true);
        } else {
            this.txtMin.setEnabled(false);
            this.txtMax.setEnabled(false);
            this.btnOrganizarPrecio.setEnabled(false);
        }

    }

    private void crearCatalogo(ArrayList<Producto> catalogo) {

        panel1.removeAll();

        panel1.setLayout(new wrapLayout(wrapLayout.CENTER, 10, 10));

        catalogo.forEach((catalogo1) -> {
            panel1.add(crearProducto(catalogo1, panel1));
        });

        panel1.validate();
        panelOpciones.validate();
        panelOpciones.repaint();
    }

    public void busquedaEspecifica(String valorBusqueda){
        ArrayList<Producto> busquedaEspecifica= new ArrayList<>();
        for (Producto prd: catalogo){
            if (prd.getNombre().toUpperCase().contains(valorBusqueda)){
                busquedaEspecifica.add(prd);
            } else if (prd.getMarca().toUpperCase().contains(valorBusqueda)){
                if (!busquedaEspecifica.contains(prd)){
                    busquedaEspecifica.add(prd);
                }
            } else if (prd.getTipo().toUpperCase().contains(valorBusqueda)){
                if (!busquedaEspecifica.contains(prd)){
                    busquedaEspecifica.add(prd);
                }
            }else {
                
            }
        }
        crearCatalogo(Buscador.preciosBajos(busquedaEspecifica));
        jLabel10.setText("Mostrando "+Buscador.preciosBajos(busquedaEspecifica).size()+" resultados.");
    }
    public final Panel crearProducto(Producto producto, Panel panel) {
        
        Licor licor;
        ImageIcon icon= new ImageIcon();
        Icon iconScale;
        Image image= new ImageIcon(getClass().getResource(producto.getImagen())).getImage();
        Panel panelProducto = new Panel();
        Dimension dimensioProducto = new Dimension(200, 200);
        panelProducto.setLayout(new BoxLayout(panelProducto, BoxLayout.Y_AXIS));
        panelProducto.setSize(dimensioProducto);
        panelProducto.setMinimumSize(dimensioProducto);
        panelProducto.setForeground(Color.black);
        JLabel cabecera = new JLabel("  ");
        JLabel nombre = new JLabel(producto.getNombre());
        JLabel precio = new JLabel("$" + String.valueOf(producto.getPrecio()));
        if(producto.getClass().equals(Licor.class)){
            licor = (Licor) producto;
            if(licor.getFactorPromocion()!=1){
        precio.setText("$" + String.valueOf(producto.getPrecio())+"  -"+
                String.valueOf(Integer.valueOf((int) (100-licor.getFactorPromocion()*100)))+"%");   
            }
        }
        
        JLabel imagen = new JLabel();
        JLabel lugar = new JLabel(producto.getPuntoVenta());
        icon.setImage(image);
        iconScale = new ImageIcon(icon.getImage().getScaledInstance(panel.getWidth()/7, panel.getWidth()/7, Image.SCALE_FAST));
        imagen.setIcon(iconScale);

        cabecera.setAlignmentX(panelProducto.CENTER_ALIGNMENT);
        imagen.setAlignmentX(panelProducto.CENTER_ALIGNMENT);
        nombre.setAlignmentX(panelProducto.CENTER_ALIGNMENT);
        precio.setAlignmentX(panelProducto.CENTER_ALIGNMENT);
        lugar.setAlignmentX(panelProducto.CENTER_ALIGNMENT);

        panelProducto.add(cabecera);
        panelProducto.add(imagen);
        panelProducto.add(nombre);
        panelProducto.add(precio);
        panelProducto.add(lugar);

        panelProducto.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                GUIProductoEspecifico mostrarProducto = new GUIProductoEspecifico(producto, catalogo, carrito,baseDatosUsuarios,controladorBaseUsuariosGeneracion,controladorBaseCatalogo);
                mostrarProducto.setVisible(rootPaneCheckingEnabled);
                dispose();
            }
        });

        panelProducto.setBackground(Color.WHITE);

        return panelProducto;

    }

    public GUIBuscador() {
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel3 = new javax.swing.JPanel();
        panelTitulo = new java.awt.Panel();
        btnSalir = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        irCarrito = new javax.swing.JButton();
        labelLogo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        panelOpciones = new java.awt.Panel();
        txtBuscadorEspecifico = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jrbMenorMayor = new javax.swing.JRadioButton();
        jrbMayorMenor = new javax.swing.JRadioButton();
        jrbAguardiente = new javax.swing.JRadioButton();
        jrbWhiskey = new javax.swing.JRadioButton();
        jrbTequila = new javax.swing.JRadioButton();
        jrbRon = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        txtMin = new javax.swing.JTextField();
        txtMax = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnBuscar = new javax.swing.JButton();
        btnOrganizarPrecio = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jrbRango = new javax.swing.JRadioButton();
        jrbGinebra = new javax.swing.JRadioButton();
        jrbCerveza = new javax.swing.JRadioButton();
        jrbVino = new javax.swing.JRadioButton();
        jrbAperitivos = new javax.swing.JRadioButton();
        jrbJumbo = new javax.swing.JRadioButton();
        jrbCarulla = new javax.swing.JRadioButton();
        jrbExito = new javax.swing.JRadioButton();
        jLabel10 = new javax.swing.JLabel();
        scrollPane1 = new java.awt.ScrollPane();
        panel1 = new java.awt.Panel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setName("Buscador"); // NOI18N

        panelTitulo.setBackground(new java.awt.Color(255, 81, 81));

        btnSalir.setBackground(new java.awt.Color(255, 204, 51));
        btnSalir.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnSalir.setText("Salir");
        btnSalir.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        jLabel9.setBackground(new java.awt.Color(255, 81, 81));
        jLabel9.setFont(new java.awt.Font("Rockwell", 2, 48)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("TriTrago");
        jLabel9.setOpaque(true);

        irCarrito.setBackground(new java.awt.Color(255, 204, 51));
        irCarrito.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        irCarrito.setText("Carrito");
        irCarrito.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        irCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                irCarritoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelTituloLayout = new javax.swing.GroupLayout(panelTitulo);
        panelTitulo.setLayout(panelTituloLayout);
        panelTituloLayout.setHorizontalGroup(
            panelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTituloLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(labelLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 538, Short.MAX_VALUE)
                .addGap(83, 83, 83)
                .addComponent(irCarrito, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58))
        );
        panelTituloLayout.setVerticalGroup(
            panelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTituloLayout.createSequentialGroup()
                .addGroup(panelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labelLogo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelTituloLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelTituloLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(panelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(irCarrito, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setBorder(null);
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        jScrollPane1.setDebugGraphicsOptions(javax.swing.DebugGraphics.BUFFERED_OPTION);
        jScrollPane1.setOpaque(false);

        panelOpciones.setBackground(new java.awt.Color(240, 240, 240));
        panelOpciones.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtBuscadorEspecifico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBuscadorEspecificoActionPerformed(evt);
            }
        });
        txtBuscadorEspecifico.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtBuscadorEspecificoKeyTyped(evt);
            }
        });
        panelOpciones.add(txtBuscadorEspecifico, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 126, -1));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("¿Qué estas buscando?");
        panelOpciones.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 6, 143, -1));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Organizar por:");
        panelOpciones.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 160, 27));

        buttonGroup1.add(jrbMenorMayor);
        jrbMenorMayor.setText("Precio: menor a mayor");
        jrbMenorMayor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbMenorMayorActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbMenorMayor, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 183, -1));

        buttonGroup1.add(jrbMayorMenor);
        jrbMayorMenor.setText("Precio:mayor a menor");
        jrbMayorMenor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbMayorMenorActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbMayorMenor, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 183, -1));

        buttonGroup1.add(jrbAguardiente);
        jrbAguardiente.setText("Aguardiente");
        jrbAguardiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbAguardienteActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbAguardiente, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 179, -1));

        buttonGroup1.add(jrbWhiskey);
        jrbWhiskey.setText("Whiskey");
        jrbWhiskey.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbWhiskeyActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbWhiskey, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, 179, -1));

        buttonGroup1.add(jrbTequila);
        jrbTequila.setText("Tequila");
        jrbTequila.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbTequilaActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbTequila, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, 179, -1));

        buttonGroup1.add(jrbRon);
        jrbRon.setText("Ron");
        jrbRon.setToolTipText("");
        jrbRon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbRonActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbRon, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 350, 179, -1));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Precio:");
        panelOpciones.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 82, -1));

        txtMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtMinKeyTyped(evt);
            }
        });
        panelOpciones.add(txtMin, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 180, 79, -1));

        txtMax.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtMaxKeyTyped(evt);
            }
        });
        panelOpciones.add(txtMax, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, 79, -1));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("min.");
        panelOpciones.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 51, 20));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("max.");
        panelOpciones.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, 51, 20));

        btnBuscar.setBackground(new java.awt.Color(255, 204, 51));
        btnBuscar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        panelOpciones.add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 30, 90, 25));

        btnOrganizarPrecio.setBackground(new java.awt.Color(255, 204, 51));
        btnOrganizarPrecio.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnOrganizarPrecio.setText("Organizar");
        btnOrganizarPrecio.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btnOrganizarPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrganizarPrecioActionPerformed(evt);
            }
        });
        panelOpciones.add(btnOrganizarPrecio, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 240, 80, 25));

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Tipo:");
        panelOpciones.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 73, -1));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Punto de venta:");
        panelOpciones.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, -1, -1));

        buttonGroup1.add(jrbRango);
        jrbRango.setText("Seleccionar rango");
        jrbRango.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbRangoActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbRango, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 184, -1));

        buttonGroup1.add(jrbGinebra);
        jrbGinebra.setText("Ginebra");
        jrbGinebra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbGinebraActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbGinebra, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, 179, -1));

        buttonGroup1.add(jrbCerveza);
        jrbCerveza.setText("Cerveza");
        jrbCerveza.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbCervezaActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbCerveza, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 179, -1));

        buttonGroup1.add(jrbVino);
        jrbVino.setText("Vino");
        jrbVino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbVinoActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbVino, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 410, 179, -1));

        buttonGroup1.add(jrbAperitivos);
        jrbAperitivos.setText("Aperitivos");
        jrbAperitivos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbAperitivosActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbAperitivos, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 430, 179, -1));

        buttonGroup1.add(jrbJumbo);
        jrbJumbo.setText("Jumbo");
        jrbJumbo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbJumboActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbJumbo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 480, -1, -1));

        buttonGroup1.add(jrbCarulla);
        jrbCarulla.setText("Carulla");
        jrbCarulla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbCarullaActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbCarulla, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 500, -1, -1));

        buttonGroup1.add(jrbExito);
        jrbExito.setText("Exito");
        jrbExito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrbExitoActionPerformed(evt);
            }
        });
        panelOpciones.add(jrbExito, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 520, -1, -1));

        jScrollPane1.setViewportView(panelOpciones);

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Mostrando resultados:");

        panel1.setBackground(new java.awt.Color(240, 240, 240));

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 813, Short.MAX_VALUE)
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 621, Short.MAX_VALUE)
        );

        scrollPane1.add(panel1);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(scrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(scrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        int respuesta = JOptionPane.showConfirmDialog(rootPane, "Esta seguro que desea salir?",
                "Confirmacion", JOptionPane.YES_NO_OPTION);
        if (respuesta == 0) {
            System.exit(0);
        }
    }//GEN-LAST:event_btnSalirActionPerformed

    private void jrbExitoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbExitoActionPerformed
        organizarPrecio(false);
        crearCatalogo(Buscador.filtroLugar(jrbExito.getText(), catalogo));
        jLabel10.validate();
        jLabel10.repaint();
        jLabel10.setText("Mostrando "+String.valueOf(Buscador.filtroLugar(jrbExito.getText(), catalogo).size())+" resultados.");
    }//GEN-LAST:event_jrbExitoActionPerformed

    private void jrbCarullaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbCarullaActionPerformed
        organizarPrecio(false);
        crearCatalogo(Buscador.filtroLugar(jrbCarulla.getText(), catalogo));
        jLabel10.validate();
        jLabel10.repaint();
        jLabel10.setText("Mostrando "+String.valueOf(Buscador.filtroLugar(jrbCarulla.getText(), catalogo).size())+" resultados.");
    }//GEN-LAST:event_jrbCarullaActionPerformed

    private void jrbJumboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbJumboActionPerformed
        organizarPrecio(false);
        crearCatalogo(Buscador.filtroLugar(jrbJumbo.getText(), catalogo));
        jLabel10.validate();
        jLabel10.repaint();
        jLabel10.setText("Mostrando "+String.valueOf(Buscador.filtroLugar(jrbJumbo.getText(), catalogo).size())+" resultados.");
    }//GEN-LAST:event_jrbJumboActionPerformed

    private void jrbAperitivosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbAperitivosActionPerformed
        organizarPrecio(false);
        crearCatalogo(Buscador.filtroTipo(jrbAperitivos.getText(), catalogo));
        jLabel10.validate();
        jLabel10.repaint();
        jLabel10.setText("Mostrando " + String.valueOf(Buscador.filtroTipo(jrbAperitivos.getText(), catalogo).size()) + " resultados.");
    }//GEN-LAST:event_jrbAperitivosActionPerformed

    private void jrbVinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbVinoActionPerformed
        organizarPrecio(false);
        crearCatalogo(Buscador.filtroTipo(jrbVino.getText(), catalogo));
        jLabel10.validate();
        jLabel10.repaint();
        jLabel10.setText("Mostrando " + String.valueOf(Buscador.filtroTipo(jrbVino.getText(), catalogo).size()) + " resultados.");
    }//GEN-LAST:event_jrbVinoActionPerformed

    private void jrbCervezaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbCervezaActionPerformed
        organizarPrecio(false);
        crearCatalogo(Buscador.filtroTipo(jrbCerveza.getText(), catalogo));
        jLabel10.validate();
        jLabel10.repaint();
        jLabel10.setText("Mostrando "+String.valueOf(Buscador.filtroTipo(jrbCerveza.getText(), catalogo).size())+" resultados.");
    }//GEN-LAST:event_jrbCervezaActionPerformed

    private void jrbGinebraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbGinebraActionPerformed
        organizarPrecio(false);
        crearCatalogo(Buscador.filtroTipo(jrbGinebra.getText(), catalogo));
        jLabel10.validate();
        jLabel10.repaint();
        jLabel10.setText("Mostrando " + String.valueOf(Buscador.filtroTipo(jrbGinebra.getText(), catalogo).size()) + " resultados.");
    }//GEN-LAST:event_jrbGinebraActionPerformed

    private void jrbRangoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbRangoActionPerformed
        // TODO add your handling code here:
        organizarPrecio(true);
    }//GEN-LAST:event_jrbRangoActionPerformed

    private void btnOrganizarPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrganizarPrecioActionPerformed
        // TODO add your handling code here:
        if (Integer.parseInt(txtMax.getText())>Integer.parseInt(txtMin.getText())){
            ArrayList<Producto> cat = Buscador.rangoPrecios(Integer.parseInt(txtMin.getText()), Integer.parseInt(txtMax.getText()), catalogo);
            crearCatalogo(cat);
            jLabel10.validate();
            jLabel10.repaint();
            jLabel10.setText("Mostrando " + String.valueOf(Buscador.rangoPrecios(Integer.parseInt(txtMin.getText()), Integer.parseInt(txtMax.getText()), catalogo).size()) + " resultados.");
        } else {
            JOptionPane.showMessageDialog(rootPane, "El precio mínimo debe ser menor al precio máximo, cambie los parámetros e intente de nuevo ",
                "Digitacion errónea", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnOrganizarPrecioActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        valorBusqueda=this.txtBuscadorEspecifico.getText().toUpperCase();
        busquedaEspecifica(valorBusqueda);
        organizarPrecio(false);
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void txtMaxKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtMaxKeyTyped
        char tecla;
        tecla=evt.getKeyChar();
        if(!Character.isDigit(tecla)){
            evt.consume();
        }        // TODO add your handling code here:
    }//GEN-LAST:event_txtMaxKeyTyped

    private void txtMinKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtMinKeyTyped
        char tecla;
        tecla=evt.getKeyChar();
        if(!Character.isDigit(tecla)){
            evt.consume();
        }        // TODO add your handling code here:
    }//GEN-LAST:event_txtMinKeyTyped

    private void jrbRonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbRonActionPerformed
        // TODO add your handling code here:
        crearCatalogo(Buscador.filtroTipo(jrbRon.getText(), catalogo));
        organizarPrecio(false);
        jLabel10.validate();
        jLabel10.repaint();
        jLabel10.setText("Mostrando "+String.valueOf(Buscador.filtroTipo(jrbRon.getText(), catalogo).size())+" resultados.");
    }//GEN-LAST:event_jrbRonActionPerformed

    private void jrbTequilaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbTequilaActionPerformed
        // TODO add your handling code here:
        crearCatalogo(Buscador.filtroTipo(jrbTequila.getText(), catalogo));
        organizarPrecio(false);
        jLabel10.validate();
        jLabel10.repaint();
        jLabel10.setText("Mostrando "+String.valueOf(Buscador.filtroTipo(jrbTequila.getText(), catalogo).size())+" resultados.");
    }//GEN-LAST:event_jrbTequilaActionPerformed

    private void jrbWhiskeyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbWhiskeyActionPerformed
        // TODO add your handling code here:
        crearCatalogo(Buscador.filtroTipo(jrbWhiskey.getText(), catalogo));
        organizarPrecio(false);
        jLabel10.validate();
        jLabel10.repaint();
        jLabel10.setText("Mostrando "+String.valueOf(Buscador.filtroTipo(jrbWhiskey.getText(), catalogo).size())+" resultados.");
    }//GEN-LAST:event_jrbWhiskeyActionPerformed

    private void jrbAguardienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbAguardienteActionPerformed
        // TODO add your handling code here:
        organizarPrecio(false);
        crearCatalogo(Buscador.filtroTipo(jrbAguardiente.getText(), catalogo));
        jLabel10.validate();
        jLabel10.repaint();
        jLabel10.setText("Mostrando "+String.valueOf(Buscador.filtroTipo(jrbAguardiente.getText(), catalogo).size())+" resultados.");
    }//GEN-LAST:event_jrbAguardienteActionPerformed

    private void jrbMayorMenorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbMayorMenorActionPerformed
        crearCatalogo(Buscador.preciosAltos(catalogo));
        jLabel10.validate();
        jLabel10.repaint();
        jLabel10.setText("Mostrando "+String.valueOf(Buscador.preciosAltos(catalogo).size())+" resultados.");
        organizarPrecio(false);
    }//GEN-LAST:event_jrbMayorMenorActionPerformed

    private void jrbMenorMayorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrbMenorMayorActionPerformed
        crearCatalogo(Buscador.preciosBajos(catalogo));
        jLabel10.validate();
        jLabel10.repaint();
        jLabel10.setText("Mostrando "+String.valueOf(Buscador.preciosBajos(catalogo).size())+" resultados.");
        organizarPrecio(false);
    }//GEN-LAST:event_jrbMenorMayorActionPerformed

    private void txtBuscadorEspecificoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscadorEspecificoKeyTyped
        char tecla;
        tecla=evt.getKeyChar();
        if(!Character.isLetter(tecla)&&!Character.isSpace(tecla)){
            evt.consume();
        }
    }//GEN-LAST:event_txtBuscadorEspecificoKeyTyped

    private void txtBuscadorEspecificoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBuscadorEspecificoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBuscadorEspecificoActionPerformed

    private void irCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_irCarritoActionPerformed
        GUICarrito carritoGUI = new GUICarrito(catalogo, carrito,controladorBaseUsuariosGeneracion,controladorBaseCatalogo,baseDatosUsuarios);
        carritoGUI.setLocationRelativeTo(null);
        carritoGUI.setVisible(rootPaneCheckingEnabled);

        dispose();
    }//GEN-LAST:event_irCarritoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUIBuscador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUIBuscador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUIBuscador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUIBuscador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GUIBuscador().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnOrganizarPrecio;
    private javax.swing.JButton btnSalir;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton irCarrito;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton jrbAguardiente;
    private javax.swing.JRadioButton jrbAperitivos;
    private javax.swing.JRadioButton jrbCarulla;
    private javax.swing.JRadioButton jrbCerveza;
    private javax.swing.JRadioButton jrbExito;
    private javax.swing.JRadioButton jrbGinebra;
    private javax.swing.JRadioButton jrbJumbo;
    private javax.swing.JRadioButton jrbMayorMenor;
    private javax.swing.JRadioButton jrbMenorMayor;
    private javax.swing.JRadioButton jrbRango;
    private javax.swing.JRadioButton jrbRon;
    private javax.swing.JRadioButton jrbTequila;
    private javax.swing.JRadioButton jrbVino;
    private javax.swing.JRadioButton jrbWhiskey;
    private javax.swing.JLabel labelLogo;
    private java.awt.Panel panel1;
    private java.awt.Panel panelOpciones;
    private java.awt.Panel panelTitulo;
    private java.awt.ScrollPane scrollPane1;
    private javax.swing.JTextField txtBuscadorEspecifico;
    private javax.swing.JTextField txtMax;
    private javax.swing.JTextField txtMin;
    // End of variables declaration//GEN-END:variables
}
