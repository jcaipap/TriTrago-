/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ui;

import Datos.CatalogoDataBaseHandler;
import Datos.Licor;
import Datos.Producto;
import Datos.Usuario;
import Datos.UsuariosDataBaseHandler;
import com.mysql.cj.xdevapi.Table;
import java.awt.Color;
import java.awt.Component;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeMap;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import logica.CarritoCompras;

/**
 *
 * @author JAndres
 */
public final class GUICarrito extends javax.swing.JFrame {

    /**
     * Creates new form GUICarrito
     */
    ArrayList<Producto> catalogo;
    ArrayList<Producto> carrito;
    private TreeMap<String, Usuario> baseDatosUsuarios;
    private CatalogoDataBaseHandler controladorBaseCatalogo;
    private UsuariosDataBaseHandler controladorBaseUsuariosGeneracion;
    public GUICarrito(ArrayList<Producto> catalogo, ArrayList<Producto> carrito, UsuariosDataBaseHandler controladorBaseUsuariosGeneracion,CatalogoDataBaseHandler controladorBaseCatalogo,TreeMap<String, Usuario> baseDatosUsuarios) {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setResizable(true);
        getContentPane().setBackground(Color.WHITE);
        this.carrito=carrito;
        this.catalogo=catalogo;
        this.controladorBaseUsuariosGeneracion=controladorBaseUsuariosGeneracion;
        this.controladorBaseCatalogo=controladorBaseCatalogo;
        this.baseDatosUsuarios=baseDatosUsuarios;
        setIconImage(new ImageIcon(getClass().getResource("/recursos/iconoPrincipal.png")).getImage());
        this.setTitle("Carrito de compras");
        addRowtoJTable(productosComprar(carrito));
        int valor=valorCuenta(carrito);
        this.lblValorCuenta.setText(String.valueOf(valor));
        ImageIcon icon= new ImageIcon();
        Icon iconScale;
        Image image= new ImageIcon(getClass().getResource("/recursos/logoPrincipal.png")).getImage();
        icon.setImage(image);
        iconScale = new ImageIcon(icon.getImage().getScaledInstance(labelLogo.getWidth(), labelLogo.getHeight(), Image.SCALE_SMOOTH));
        labelLogo.setIcon(iconScale);

    }

    public int valorCuenta(ArrayList<Producto> carrito){
        int valor=0;
        for (Producto producto: carrito){
            valor=valor+producto.getPrecio();
        }
        return valor;
    }
    public ArrayList<Producto> productosComprar(ArrayList<Producto> productos){
        boolean repetido;
        ArrayList<Producto> productosTabla = new ArrayList<>();
        for(int i = 0;i<productos.size();i++){
            repetido = false;
            if(i==0){
                productosTabla.add(productos.get(i));
                continue; 
            }  
            for(int j = 0;j<productosTabla.size();j++){  
                if(productos.get(i).equals(productosTabla.get(j))){
                    repetido=true;   
                }  
            } 
            if(!repetido){
                productosTabla.add(productos.get(i));
                }    
        }
        return productosTabla;
    }
    
    public int cantidadRepetido(Producto producto, ArrayList<Producto> carrito){
        int cantidad=0;
        for(int i=0;i<carrito.size();i++){
            if(carrito.get(i).equals(producto)){
                cantidad++;
            }
        }
        return cantidad;
    }
    
    public void addRowtoJTable(ArrayList<Producto> productos){
        String[] columnas = new String[]{
            "Indice", "Lugar", "Tipo", "Nombre", "Precio Unidad", "Descuento", "Cantidad", "Total a pagar", "Eliminar"
        };
        final Class[] tiposColumnas = new Class[]{
            int.class,
            java.lang.String.class,
            java.lang.String.class,
            java.lang.String.class,
            java.lang.Integer.class,
            java.lang.String.class,
            int.class,
            java.lang.String.class,
            JButton.class
        };
        Object[][] datos = new Object[50][9];

        for (int i = 0; i < productos.size(); i++) {
            Producto pr = productos.get(i);
            datos[i][0] = i+1;
            datos[i][1] = pr.getPuntoVenta();
            datos[i][2] = pr.getTipo();
            datos[i][3] = pr.getNombre();
            datos[i][4] = pr.getPrecio();
            datos[i][5] = promocion(pr);
            datos[i][6] = cantidadRepetido(productos.get(i), carrito);
            datos[i][7] = String.valueOf(productos.get(i).getPrecio() * cantidadRepetido(productos.get(i), carrito)) + "$";
            datos[i][8] = new JButton("Eliminar");
        }
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
                datos,
                columnas) {
            Class[] tipos = tiposColumnas;

            @Override
            public Class getColumnClass(int columnIndex) {
                return tipos[columnIndex];
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                return !(this.getColumnClass(column).equals(JButton.class));
            }
        });
        jTable1.setDefaultRenderer(JButton.class, new TableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable jtable, Object objeto, boolean estaSeleccionado, boolean tieneElFoco, int fila, int columna) {
                return (Component) objeto;
            }
        });
        jTable1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila = jTable1.rowAtPoint(e.getPoint());
                int columna = jTable1.columnAtPoint(e.getPoint());
                if (jTable1.getModel().getColumnClass(columna).equals(JButton.class)) {
                    ArrayList<Producto> eliminar=productosComprar(carrito);
                    String nombreBorrar=String.valueOf(jTable1.getValueAt(jTable1.rowAtPoint(e.getPoint()),3));
                    String cBorrar=String.valueOf(jTable1.getValueAt(jTable1.rowAtPoint(e.getPoint()),6));
                    int cantidadBorrar=Integer.parseInt(cBorrar);
                    carrito=CarritoCompras.eliminarProducto(carrito, nombreBorrar,cantidadBorrar);
                    DefaultTableModel model=new DefaultTableModel();
                    model=(DefaultTableModel)jTable1.getModel();
                    model.removeRow(jTable1.getSelectedRow());
                    int valor=valorCuenta(carrito);
                    lblValorCuenta.setText(String.valueOf(valor));
                    for (Producto pr: catalogo){
                        if (nombreBorrar.equals(pr.getNombre())){
                            pr.setCantidadProductos(pr.getCantidadProductos()+cantidadBorrar);
                        }
                    }

                }
            }
        });
    }

    public String promocion(Producto producto) {
        Licor productoLicor = (Licor) producto;
        String descuento = "";
        if (productoLicor.getFactorPromocion() != 1) {
            descuento = String.valueOf(100 - productoLicor.getFactorPromocion() * 100) + "%";
        }
        return descuento;
    }
        
 
    public GUICarrito() {
    }

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        panel2 = new java.awt.Panel();
        salirPrograma = new javax.swing.JButton();
        VolverCatalogo = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        labelLogo = new javax.swing.JLabel();
        panel5 = new java.awt.Panel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        lblValorCuenta = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jScrollPane1.setBackground(Color.WHITE);

        jTable1.setBackground(Color.WHITE);
        jTable1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Indice", "Lugar", "Tipo", "Nombre", "Precio unidad", "Descuento", "Cantidad", "Total a pagar", "null"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        jTable1.setGridColor(new java.awt.Color(255, 255, 255));
        jTable1.setOpaque(false);
        jTable1.setSelectionBackground(new java.awt.Color(255, 81, 81));
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(1).setResizable(false);
        }

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 770, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panel2.setBackground(new java.awt.Color(255, 81, 81));
        panel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        salirPrograma.setBackground(new java.awt.Color(255, 204, 51));
        salirPrograma.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        salirPrograma.setText("Salir");
        salirPrograma.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        salirPrograma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirProgramaActionPerformed(evt);
            }
        });

        VolverCatalogo.setBackground(new java.awt.Color(255, 204, 51));
        VolverCatalogo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        VolverCatalogo.setText("Volver a catálogo");
        VolverCatalogo.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        VolverCatalogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VolverCatalogoActionPerformed(evt);
            }
        });

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Rockwell", 2, 48)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("TriTrago");

        jLabel10.setBackground(new java.awt.Color(255, 81, 81));
        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 26)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Carrito de compras");
        jLabel10.setOpaque(true);

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(VolverCatalogo, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(labelLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(salirPrograma, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
            .addGroup(panel2Layout.createSequentialGroup()
                .addGap(140, 140, 140)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panel2Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(salirPrograma, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(VolverCatalogo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(labelLogo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(15, 15, 15)))
                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE)
                .addGap(7, 7, 7))
        );

        panel5.setBackground(new java.awt.Color(255, 81, 81));

        jButton1.setBackground(new java.awt.Color(255, 204, 51));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton1.setText("Comprar");
        jButton1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Valor total a pagar");

        lblValorCuenta.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblValorCuenta.setText("jLabel2");

        javax.swing.GroupLayout panel5Layout = new javax.swing.GroupLayout(panel5);
        panel5.setLayout(panel5Layout);
        panel5Layout.setHorizontalGroup(
            panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel5Layout.createSequentialGroup()
                .addGap(173, 173, 173)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(lblValorCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55))
        );
        panel5Layout.setVerticalGroup(
            panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblValorCuenta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(panel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(panel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void salirProgramaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirProgramaActionPerformed

        int respuesta = JOptionPane.showConfirmDialog(panel2, "Esta seguro que desea salir?",
            "confirmacion", JOptionPane.YES_NO_OPTION);
        if(respuesta==0){
            System.exit(0);
        }
    }//GEN-LAST:event_salirProgramaActionPerformed

    private void VolverCatalogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VolverCatalogoActionPerformed
        // TODO add your handling code here:

        GUIBuscador buscador = new GUIBuscador(catalogo,carrito,controladorBaseUsuariosGeneracion,controladorBaseCatalogo,baseDatosUsuarios);
        buscador.setVisible(true);
        dispose();

    }//GEN-LAST:event_VolverCatalogoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
        
        GUIPago pago = new GUIPago( baseDatosUsuarios,catalogo, controladorBaseUsuariosGeneracion,controladorBaseCatalogo, carrito);
        pago.setVisible(true);
        dispose();
        
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUICarrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUICarrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUICarrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUICarrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GUICarrito().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton VolverCatalogo;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel labelLogo;
    private javax.swing.JLabel lblValorCuenta;
    private java.awt.Panel panel2;
    private java.awt.Panel panel5;
    private javax.swing.JButton salirPrograma;
    // End of variables declaration//GEN-END:variables
}
