
package Datos;

import java.io.Serializable;
import java.util.ArrayList;

public class ComboLicor extends Producto implements Serializable{
    private ArrayList<Licor> listaCombo;
    private double precioTotal;

    public ComboLicor(ArrayList<Licor> listaCombo, double precioTotal, String tipo,int codigo, String nombre, String marca, String volumen, String porcentajeAlcohol, int precio, String puntoVenta,int cantidadProductos, String imagen) {
        super(tipo, codigo, nombre, marca, volumen, porcentajeAlcohol, precio, puntoVenta, cantidadProductos, imagen);
        this.listaCombo = listaCombo;
        this.precioTotal = precioTotal;
    }



    public ArrayList<Licor> getListaCombo() {
        return listaCombo;
    }

    public void setListaCombo(ArrayList<Licor> listaCombo) {
        this.listaCombo = listaCombo;
    }

    public double getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(double precioTotal) {
        this.precioTotal = precioTotal;
    }
    
}
