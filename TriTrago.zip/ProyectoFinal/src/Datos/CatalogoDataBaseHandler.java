
package Datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CatalogoDataBaseHandler {
    public String db="catalogodb1";
    public String url="jdbc:mysql://den1.mysql6.gear.host/catalogodb1?useTimezone=true&serverTimezone=UTC";
    public String userDb="catalogodb1";
    public String passwordDb="Pq6aDI_d-Pp0";
    public final String img="/recursos/";
    
    Connection cnU;
    Statement stU;  
    PreparedStatement pstU;

    public CatalogoDataBaseHandler() {
        
    }

    
    public ArrayList<Licor> LeerDBC(){
        ArrayList<Licor> listaCatalogo=new ArrayList<>();
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            cnU=DriverManager.getConnection(url, userDb, passwordDb);
            stU=cnU.createStatement();
            ResultSet rsU=stU.executeQuery("select * from tcatalogo");
            while (rsU.next()){
                Integer nuevoPrecio=rsU.getInt("Precio");  
                Double promocion=rsU.getDouble("Promocion");
                promocion=(nuevoPrecio.doubleValue()*promocion);
                nuevoPrecio=promocion.intValue();
                Licor licorD=new Licor(rsU.getString("Tipo"),rsU.getDouble("Promocion"),rsU.getInt("codigo"),rsU.getString("Nombre"),rsU.getString("Marca"),rsU.getString("Volumen"),rsU.getString("Porcentaje"),nuevoPrecio,rsU.getString("PuntoVenta"),rsU.getInt("CantidadProductos"),img+rsU.getString("Imagen"));
                listaCatalogo.add(licorD);
            }
            rsU.close();
            stU.close();
        } catch(ClassNotFoundException e){
            e.printStackTrace();
        } catch(SQLException ex){
            Logger.getLogger(UsuariosDataBaseHandler.class.getName()).log(Level.SEVERE, null, ex);
        }finally{            
            try{
                cnU.close();
            }catch(SQLException exc){
            
            }
        }
        return listaCatalogo;
    }
    public void InsertarDBC (int codigo,String nombre,String marca, String volumen, String porcentaje, int precio, String puntoVenta, String tipo,double promocion,int cantidadProductos,String img){
        try{            
            Class.forName("com.mysql.cj.jdbc.Driver");
            cnU=DriverManager.getConnection(url,userDb,passwordDb);
            pstU=cnU.prepareStatement("INSERT INTO tcatalogo(codigo,Nombre,Marca,Volumen,Porcentaje,Precio,PuntoVenta,Tipo,Promocion,CantidadProductos,Imagen)VALUES(?,?,?,?,?,?,?,?,?,?,?)");
            pstU.setInt(1, codigo);
            pstU.setString(2,nombre);
            pstU.setString(3,marca);
            pstU.setString(4,volumen);
            pstU.setString(5,porcentaje);
            pstU.setInt(6,precio);
            pstU.setString(7,puntoVenta);
            pstU.setString(8,tipo);
            pstU.setDouble(9,promocion);
            pstU.setInt(10,cantidadProductos);
            pstU.setString(11,img);
            pstU.executeUpdate();
            pstU.close();
        }catch (SQLException e){
            Logger.getLogger(UsuariosDataBaseHandler.class.getName()).log(Level.SEVERE, null,e);
        } catch (ClassNotFoundException ex){
            ex.printStackTrace();
        } finally{
            try{
                cnU.close();
            }catch(SQLException exc){
                
            }
        }
        
    }
    
    public void ModificarDBC (int codigo,int cantidadProductos){
        try{            
            Class.forName("com.mysql.cj.jdbc.Driver");
            cnU=DriverManager.getConnection(url,userDb,passwordDb);
            int nuevaCantidad=cantidadProductos-1;
            pstU=cnU.prepareStatement("UPDATE tcatalogo SET CantidadProductos='"+nuevaCantidad+"' WHERE codigo="+codigo );
            pstU.executeUpdate();
            pstU.close();
        }catch (SQLException e){
            Logger.getLogger(UsuariosDataBaseHandler.class.getName()).log(Level.SEVERE, null,e);
        } catch (ClassNotFoundException ex){
            ex.printStackTrace();
        } finally{
            try{
                cnU.close();
            }catch(SQLException exc){
                
            }
        }
        
    }
    
    
}
