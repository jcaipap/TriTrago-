
package Datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UsuariosDataBaseHandler {
    public String db="usuariosdb";
    public String url="jdbc:mysql://den1.mysql6.gear.host/usuariosdb?useTimezone=true&serverTimezone=UTC";
    public String userDb="usuariosdb";
    public String passwordDb="Zy2C!s6o57!F";
    
    Connection cnU;
    Statement stU;  
    PreparedStatement pstU;

    public UsuariosDataBaseHandler() {
    }
    
    public TreeMap<String,Usuario> LeerDBU(){
        TreeMap<String,Usuario> listaUsuarios=new TreeMap<>();
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            cnU=DriverManager.getConnection(url, userDb, passwordDb);
            stU=cnU.createStatement();
            ResultSet rsU=stU.executeQuery("select * from tusuarios");
            while (rsU.next()){
                Usuario usuarioD= new Usuario(rsU.getInt("id"),rsU.getString("Nombre"),rsU.getString("Apellido"),rsU.getInt("Edad"),rsU.getString("Correo"),rsU.getString("Usuario"),rsU.getString("Contraseña"));
                listaUsuarios.put(rsU.getString("Usuario"),usuarioD);
            }
            rsU.close();
            stU.close();
        } catch(ClassNotFoundException e){
        } catch(SQLException ex){
            Logger.getLogger(UsuariosDataBaseHandler.class.getName()).log(Level.SEVERE, null, ex);
        }finally{            
            try{
                cnU.close();
            }catch(SQLException exc){
            
            }
        }
        return listaUsuarios;
    }
    public void InsertarDBU (int id,String nombre,String apellido, int edad, String correo, String usuario, String contraseña){
        try{            
            Class.forName("com.mysql.cj.jdbc.Driver");
            cnU=DriverManager.getConnection(url,userDb,passwordDb);
            pstU=cnU.prepareStatement("INSERT INTO tusuarios(id,Nombre,Apellido,Edad,Correo,Usuario,Contraseña)VALUES(?,?,?,?,?,?,?)");
            pstU.setInt(1, id);
            pstU.setString(2,nombre);
            pstU.setString(3,apellido);
            pstU.setInt(4,edad);
            pstU.setString(5,correo);
            pstU.setString(6,usuario);
            pstU.setString(7,contraseña);
            pstU.executeUpdate();
            pstU.close();
        }catch (SQLException e){
            Logger.getLogger(UsuariosDataBaseHandler.class.getName()).log(Level.SEVERE, null,e);
        } catch (ClassNotFoundException ex){
        } finally{
            try{
                cnU.close();
            }catch(SQLException exc){
                
            }
        }
        
    }
    
}
