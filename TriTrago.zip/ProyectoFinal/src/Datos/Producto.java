
package Datos;

import java.io.Serializable;

/**
 *
 * @author JAndres
 */
public abstract class Producto implements Serializable {
    private int codigo;
    private String nombre;
    private String marca;
    private String volumen;
    private String porcentajeAlcohol;
    private int precio;
    private String puntoVenta;
    private int cantidadProductos;
    private String imagen;
    private String tipo;

    public Producto(String tipo,int codigo,String nombre, String marca, String volumen, String porcentajeAlcohol, int precio, String puntoVenta,int cantidadProductos,String imagen) {
        this.tipo=tipo;
        this.codigo=codigo;
        this.nombre = nombre;
        this.marca = marca;
        this.volumen = volumen;
        this.porcentajeAlcohol = porcentajeAlcohol;
        this.precio = precio;
        this.puntoVenta = puntoVenta;
        this.cantidadProductos =cantidadProductos;
        this.imagen = imagen;
    }

    @Override
    public String toString() {
        return "Producto{" + "codigo=" + codigo + ", nombre=" + nombre + ", marca=" + marca + ", volumen=" + volumen + ", porcentajeAlcohol=" + porcentajeAlcohol + ", precio=" + precio + ", puntoVenta=" + puntoVenta + ", cantidadProductos=" + cantidadProductos + ", imagen=" + imagen + ", tipo=" + tipo + '}';
    }



    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getVolumen() {
        return volumen;
    }

    public void setVolumen(String volumen) {
        this.volumen = volumen;
    }

    public String getPorcentajeAlcohol() {
        return porcentajeAlcohol;
    }

    public void setPorcentajeAlcohol(String porcentajeAlcohol) {
        this.porcentajeAlcohol = porcentajeAlcohol;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getPuntoVenta() {
        return puntoVenta;
    }

    public void setPuntoVenta(String puntoVenta) {
        this.puntoVenta = puntoVenta;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getCantidadProductos() {
        return cantidadProductos;
    }

    public void setCantidadProductos(int cantidadProductos) {
        this.cantidadProductos = cantidadProductos;
    }
    
    
    
    
}
