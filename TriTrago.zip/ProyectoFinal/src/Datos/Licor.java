
package Datos;

import java.io.Serializable;


public class Licor extends Producto implements Serializable{

    private double factorPromocion;

    public Licor(String tipo, double factorPromocion, int codigo, String nombre, String marca, String volumen, String porcentajeAlcohol, int precio, String puntoVenta,int cantidadProductos, String imagen) {
        super(tipo, codigo, nombre, marca, volumen, porcentajeAlcohol, precio, puntoVenta,cantidadProductos, imagen);

        this.factorPromocion = factorPromocion;
    }

    @Override
    public String toString() {
        return super.toString() + "factorPromocion=" + factorPromocion + '}';
    }


    public double getFactorPromocion() {
        return factorPromocion;
    }

    public void setFactorPromocion(double factorPromocion) {
        this.factorPromocion = factorPromocion;
    }
    
}
